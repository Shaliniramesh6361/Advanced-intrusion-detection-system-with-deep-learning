// Global variables
let predictionHistory = [];
const sampleData = {
  "duration": 0,
  "protocol_type": "tcp",
  "service": "http",
  "flag": "SF",
  "src_bytes": 215,
  "dst_bytes": 45076,
  "land": 0,
  "wrong_fragment": 0,
  "urgent": 0,
  "hot": 0,
  "num_failed_logins": 0,
  "logged_in": 1,
  "num_compromised": 0,
  "root_shell": 0,
  "su_attempted": 0,
  "num_root": 0,
  "num_file_creations": 0,
  "num_shells": 0,
  "num_access_files": 0,
  "num_outbound_cmds": 0,
  "is_host_login": 0,
  "is_guest_login": 0,
  "count": 1,
  "srv_count": 1,
  "serror_rate": 0,
  "srv_serror_rate": 0,
  "rerror_rate": 0,
  "srv_rerror_rate": 0,
  "same_srv_rate": 1,
  "diff_srv_rate": 0,
  "srv_diff_host_rate": 0,
  "dst_host_count": 9,
  "dst_host_srv_count": 9,
  "dst_host_same_srv_rate": 1,
  "dst_host_diff_srv_rate": 0,
  "dst_host_same_src_port_rate": 0.11,
  "dst_host_srv_diff_host_rate": 0,
  "dst_host_serror_rate": 0,
  "dst_host_srv_serror_rate": 0,
  "dst_host_rerror_rate": 0,
  "dst_host_srv_rerror_rate": 0
};

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Check API health status on load
  checkApiHealth();
  
  // Set up event listeners
  document.getElementById('loadSampleBtn').addEventListener('click', loadSampleData);
  document.getElementById('clearJsonBtn').addEventListener('click', clearJsonEditor);
  document.getElementById('analyzeBtn').addEventListener('click', analyzeTraffic);
  
  // Initialize tabs
  setupTabs();
  
  // Populate the simple form with protocol types and common services
  populateSimpleForm();
});

// Check API health status
function checkApiHealth() {
  const healthStatusEl = document.getElementById('healthStatus');
  
  fetch('/health')
    .then(response => response.json())
    .then(data => {
      if (data.status === 'ok') {
        healthStatusEl.textContent = 'Online';
        healthStatusEl.className = 'badge badge-normal';
      } else {
        healthStatusEl.textContent = 'Offline';
        healthStatusEl.className = 'badge badge-malicious';
      }
    })
    .catch(error => {
      console.error('API Health Check Error:', error);
      healthStatusEl.textContent = 'Offline';
      healthStatusEl.className = 'badge badge-malicious';
    });
}

// Load sample data into the JSON editor
function loadSampleData() {
  const jsonEditor = document.getElementById('jsonInput');
  jsonEditor.value = JSON.stringify(sampleData, null, 2);
}

// Clear the JSON editor
function clearJsonEditor() {
  document.getElementById('jsonInput').value = '';
}

// Analyze network traffic
function analyzeTraffic() {
  // Show loading spinner
  const resultBox = document.getElementById('resultBox');
  const loadingSpinner = document.getElementById('loadingSpinner');
  const resultContent = document.getElementById('resultContent');
  
  resultBox.style.display = 'block';
  loadingSpinner.style.display = 'block';
  resultContent.style.display = 'none';
  
  // Get input data (prioritize JSON input over simple form)
  let inputData;
  const jsonInput = document.getElementById('jsonInput').value.trim();
  
  if (jsonInput) {
    try {
      inputData = JSON.parse(jsonInput);
    } catch (e) {
      alert('Invalid JSON format. Please check your input.');
      resultBox.style.display = 'none';
      return;
    }
  } else {
    // Get data from simple form
    inputData = getSimpleFormData();
  }
  
  // Send request to API
  fetch('/predict', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(inputData)
  })
    .then(response => response.json())
    .then(data => {
      // Hide loading spinner
      loadingSpinner.style.display = 'none';
      resultContent.style.display = 'block';
      
      // Display the result
      displayResult(data, inputData);
      
      // Add to history
      addToHistory(data, inputData);
    })
    .catch(error => {
      console.error('Error:', error);
      loadingSpinner.style.display = 'none';
      resultContent.innerHTML = `
        <div class="alert alert-danger">
          <h3>Error</h3>
          <p>Failed to analyze network traffic. Please try again.</p>
          <p>Error details: ${error.message}</p>
        </div>
      `;
      resultContent.style.display = 'block';
    });
}

// Display prediction result
function displayResult(result, inputData) {
  const resultContent = document.getElementById('resultContent');
  const resultBox = document.getElementById('resultBox');
  
  // Determine result type for styling
  const isNormal = result.prediction === 'Normal';
  const resultClass = isNormal ? 'result-normal' : 'result-malicious';
  const fillClass = isNormal ? 'normal-fill' : 'malicious-fill';
  
  // Format the confidence percentage
  const confidencePercent = (result.confidence * 100).toFixed(2);
  
  // Update result box styling
  resultBox.className = `result-box ${resultClass}`;
  
  // Build the HTML content
  resultContent.innerHTML = `
    <h3>
      Prediction: <span class="badge ${isNormal ? 'badge-normal' : 'badge-malicious'}">
        ${result.prediction}
      </span>
    </h3>
    <p>Confidence Level: ${confidencePercent}%</p>
    <div class="confidence-meter">
      <div class="confidence-fill ${fillClass}" style="width: ${confidencePercent}%"></div>
    </div>
    <div class="prediction-details">
      <p><strong>Protocol:</strong> ${inputData.protocol_type}</p>
      <p><strong>Service:</strong> ${inputData.service}</p>
      <p><strong>Source Bytes:</strong> ${inputData.src_bytes}</p>
      <p><strong>Destination Bytes:</strong> ${inputData.dst_bytes}</p>
    </div>
    <div class="mt-3">
      <h4>Raw Response:</h4>
      <pre>${JSON.stringify(result, null, 2)}</pre>
    </div>
  `;
}

// Add prediction to history
function addToHistory(result, inputData) {
  // Add to the history array (limit to last 10 items)
  predictionHistory.unshift({
    timestamp: new Date(),
    result: result,
    inputData: inputData
  });
  
  if (predictionHistory.length > 10) {
    predictionHistory.pop();
  }
  
  // Update the history UI
  updateHistoryUI();
}

// Update the history section in the UI
function updateHistoryUI() {
  const historyList = document.getElementById('historyList');
  historyList.innerHTML = '';
  
  if (predictionHistory.length === 0) {
    historyList.innerHTML = '<p>No prediction history yet.</p>';
    return;
  }
  
  predictionHistory.forEach((item, index) => {
    const isNormal = item.result.prediction === 'Normal';
    const historyClass = isNormal ? 'history-normal' : 'history-malicious';
    const timestamp = new Date(item.timestamp).toLocaleTimeString();
    
    const historyItem = document.createElement('div');
    historyItem.className = `history-item ${historyClass}`;
    historyItem.innerHTML = `
      <div class="history-header">
        <span class="badge ${isNormal ? 'badge-normal' : 'badge-malicious'}">
          ${item.result.prediction}
        </span>
        <span class="timestamp">${timestamp}</span>
      </div>
      <div class="history-details">
        <p><strong>Protocol:</strong> ${item.inputData.protocol_type}</p>
        <p><strong>Service:</strong> ${item.inputData.service}</p>
        <p><strong>Confidence:</strong> ${(item.result.confidence * 100).toFixed(2)}%</p>
      </div>
    `;
    
    historyList.appendChild(historyItem);
  });
}

// Setup tabs for switching between JSON and Simple inputs
function setupTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs
      tabs.forEach(t => t.classList.remove('active'));
      
      // Add active class to clicked tab
      tab.classList.add('active');
      
      // Hide all tab contents
      tabContents.forEach(content => {
        content.style.display = 'none';
      });
      
      // Show the corresponding tab content
      const tabId = tab.getAttribute('data-tab');
      document.getElementById(tabId).style.display = 'block';
    });
  });
  
  // Set default tab
  tabs[0].click();
}

// Populate the simple form with options
function populateSimpleForm() {
  const protocolSelect = document.getElementById('protocolType');
  const serviceSelect = document.getElementById('service');
  
  // Protocol types
  const protocols = ['tcp', 'udp', 'icmp'];
  protocols.forEach(protocol => {
    const option = document.createElement('option');
    option.value = protocol;
    option.textContent = protocol.toUpperCase();
    protocolSelect.appendChild(option);
  });
  
  // Common services
  const services = [
    'http', 'ftp', 'smtp', 'ssh', 'dns', 'ftp_data',
    'irc', 'pop3', 'telnet', 'ecr_i', 'other'
  ];
  
  services.forEach(service => {
    const option = document.createElement('option');
    option.value = service;
    option.textContent = service;
    serviceSelect.appendChild(option);
  });
}

// Get data from the simple form
function getSimpleFormData() {
  // Create a basic object with the minimal required fields
  const formData = {
    protocol_type: document.getElementById('protocolType').value,
    service: document.getElementById('service').value,
    src_bytes: parseInt(document.getElementById('srcBytes').value) || 0,
    dst_bytes: parseInt(document.getElementById('dstBytes').value) || 0,
    flag: "SF",
    duration: 0,
    land: 0,
    wrong_fragment: 0,
    urgent: 0,
    hot: 0,
    num_failed_logins: 0,
    logged_in: 1,
    num_compromised: 0,
    root_shell: 0,
    su_attempted: 0,
    num_root: 0,
    num_file_creations: 0,
    num_shells: 0,
    num_access_files: 0,
    num_outbound_cmds: 0,
    is_host_login: 0,
    is_guest_login: 0,
    count: 1,
    srv_count: 1,
    serror_rate: 0,
    srv_serror_rate: 0,
    rerror_rate: 0,
    srv_rerror_rate: 0,
    same_srv_rate: 1,
    diff_srv_rate: 0,
    srv_diff_host_rate: 0,
    dst_host_count: 9,
    dst_host_srv_count: 9,
    dst_host_same_srv_rate: 1,
    dst_host_diff_srv_rate: 0,
    dst_host_same_src_port_rate: 0.11,
    dst_host_srv_diff_host_rate: 0,
    dst_host_serror_rate: 0,
    dst_host_srv_serror_rate: 0,
    dst_host_rerror_rate: 0,
    dst_host_srv_rerror_rate: 0
  };
  
  return formData;
} 